import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';



class Trans {
  static Map? data;
  static String? activeLang = 'en';

  Trans(){
    readJson();
  }
  static Future<bool> readJson() async {
    SharedPreferences _s = await SharedPreferences.getInstance();
    activeLang = _s.getString('lang') ?? 'en';
    final String response = await rootBundle.loadString('assets/langs/$activeLang.json');
    data = await json.decode(response);
    return true;
  }

  static String trans (val){
    return data?[val] ?? val;
  }
}