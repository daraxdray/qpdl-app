import 'dart:io';

import 'package:diagon/view/start_page.dart';
import 'package:flutter/material.dart';
import 'package:diagon/models/translator.dart';
import 'package:diagon/utility/basket.dart';
import 'package:diagon/view/onboarding.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {

  WidgetsFlutterBinding.ensureInitialized();
  // await Permission.camera.request();
  // await Permission.microphone.request();
  // await Permission.storage.request();

  // if (Platform.isAndroid) {
  //   // await AndroidInAppWebViewController. setWebContentsDebuggingEnabled(true);
  //
  //   // var swAvailable = await AndroidWebViewFeature.isFeatureSupported(
  //   //     AndroidWebViewFeature.SERVICE_WORKER_BASIC_USAGE);
  //   // var swInterceptAvailable = await AndroidWebViewFeature.isFeatureSupported(
  //   //     AndroidWebViewFeature.SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST);
  //
  //   if (swAvailable && swInterceptAvailable) {
  //     // AndroidServiceWorkerController serviceWorkerController =
  //     // AndroidServiceWorkerController.instance();
  //
  //     serviceWorkerController.serviceWorkerClient = AndroidServiceWorkerClient(
  //       shouldInterceptRequest: (request) async {
  //         print(request);
  //         return null;
  //       },
  //     );
  //   }
  // }


  runApp(const MyApp());

}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Trash Coin',
        theme: ThemeData(
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.
          primaryColor: MaterialColor(basket['primaryHex'], basket['colorSwatches']),
          primaryColorBrightness: Brightness.light,
          primaryColorDark: Colors.red[700],
          appBarTheme: AppBarTheme(
            color: Color.fromARGB(247, 239, 239, 238),
            elevation: 0,
          ),
          iconTheme: IconThemeData(
              color: basket['PrimaryColor']
          ),
          splashColor: basket['PrimaryColor'],
          elevatedButtonTheme:  ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  primary: basket['PrimaryColor'], // background color
                  textStyle: const TextStyle(fontSize: 20, fontStyle: FontStyle.normal))),
          textTheme: TextTheme(bodyText1: basket['bodyText'],),
          textButtonTheme: TextButtonThemeData(style:TextButton.styleFrom()),
          inputDecorationTheme: InputDecorationTheme(
              border: UnderlineInputBorder(
                  borderSide: BorderSide(color: basket['PrimaryColor'])
              )
          ),

        ),
        home:
      FutureBuilder(
        future: Trans.readJson(),
        builder: (BuildContext context, AsyncSnapshot<void> snapshot) {

          if(snapshot.hasData){
            return const StartPage();
          }
            debugPrint(snapshot.hasError.toString());

          if(snapshot.hasError){
            return Scaffold(
              body: Center(
                  child: Text("Error...",style: basket['BlackLabelText'])
              ),
            );
          }
          return Scaffold(
            body: Center(
                child: Text("Loading...",style: basket['BlackLabelText'])
            ),
          );

        },

      ),
    );
  }
}

