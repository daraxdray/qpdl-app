import 'package:flutter/cupertino.dart';

class TopClipArt extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    Path path = Path();
    final double _xScaling = size.width / 414;
    final double _yScaling = size.height / 896;
    path.lineTo(208.262 * _xScaling,-396.25 * _yScaling);
    path.cubicTo(275.404 * _xScaling,-393.566 * _yScaling,339.237 * _xScaling,-372.084 * _yScaling,394.998 * _xScaling,-334.588 * _yScaling,);
    path.cubicTo(452.485 * _xScaling,-295.932 * _yScaling,501.912 * _xScaling,-245.649 * _yScaling,527.786 * _xScaling,-181.387 * _yScaling,);
    path.cubicTo(554.945 * _xScaling,-113.937 * _yScaling,580.878 * _xScaling,-30.6274 * _yScaling,542.17 * _xScaling,30.926 * _yScaling,);
    path.cubicTo(503.451 * _xScaling,92.4975 * _yScaling,408.709 * _xScaling,75.7591 * _yScaling,344.542 * _xScaling,110.006 * _yScaling,);
    path.cubicTo(293.742 * _xScaling,137.119 * _yScaling,265.025 * _xScaling,199.455 * _yScaling,208.262 * _xScaling,209.139 * _yScaling,);
    path.cubicTo(147.361 * _xScaling,219.529 * _yScaling,86.8609 * _xScaling,194.081 * _yScaling,33.4177 * _xScaling,163.085 * _yScaling,);
    path.cubicTo(-25.0483 * _xScaling,129.176 * _yScaling,-91.1911 * _xScaling,90.693 * _yScaling,-108.577 * _xScaling,25.3798 * _yScaling,);
    path.cubicTo(-125.795 * _xScaling,-39.3036 * _yScaling,-73.4801 * _xScaling,-98.7323 * _yScaling,-53.262 * _xScaling,-162.542 * _yScaling,);
    path.cubicTo(-32.8341 * _xScaling,-227.013 * _yScaling,-40.0769 * _xScaling,-304.902 * _yScaling,10.3517 * _xScaling,-349.967 * _yScaling,);
    path.cubicTo(62.1365 * _xScaling,-396.244 * _yScaling,138.868 * _xScaling,-399.025 * _yScaling,208.262 * _xScaling,-396.25 * _yScaling,);
    path.cubicTo(208.262 * _xScaling,-396.25 * _yScaling,208.262 * _xScaling,-396.25 * _yScaling,208.262 * _xScaling,-396.25 * _yScaling,);
    return path;
  }
  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => true;

}

class FullClipArt extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    Path path = Path();
    final double _xScaling = size.width / 324;
    final double _yScaling = size.height / 236;
    path.lineTo(208.262 * _xScaling,-396.25 * _yScaling);
    path.cubicTo(275.404 * _xScaling,-393.566 * _yScaling,339.237 * _xScaling,-372.084 * _yScaling,394.998 * _xScaling,-334.588 * _yScaling,);
    path.cubicTo(452.485 * _xScaling,-295.932 * _yScaling,501.912 * _xScaling,-245.649 * _yScaling,527.786 * _xScaling,-181.387 * _yScaling,);
    path.cubicTo(554.945 * _xScaling,-113.937 * _yScaling,580.878 * _xScaling,-30.6274 * _yScaling,542.17 * _xScaling,30.926 * _yScaling,);
    path.cubicTo(503.451 * _xScaling,92.4975 * _yScaling,408.709 * _xScaling,75.7591 * _yScaling,344.542 * _xScaling,110.006 * _yScaling,);
    path.cubicTo(293.742 * _xScaling,137.119 * _yScaling,265.025 * _xScaling,199.455 * _yScaling,208.262 * _xScaling,209.139 * _yScaling,);
    path.cubicTo(147.361 * _xScaling,219.529 * _yScaling,86.8609 * _xScaling,194.081 * _yScaling,33.4177 * _xScaling,163.085 * _yScaling,);
    path.cubicTo(-25.0483 * _xScaling,129.176 * _yScaling,-91.1911 * _xScaling,90.693 * _yScaling,-108.577 * _xScaling,25.3798 * _yScaling,);
    path.cubicTo(-125.795 * _xScaling,-39.3036 * _yScaling,-73.4801 * _xScaling,-98.7323 * _yScaling,-53.262 * _xScaling,-162.542 * _yScaling,);
    path.cubicTo(-32.8341 * _xScaling,-227.013 * _yScaling,-40.0769 * _xScaling,-304.902 * _yScaling,10.3517 * _xScaling,-349.967 * _yScaling,);
    path.cubicTo(62.1365 * _xScaling,-396.244 * _yScaling,138.868 * _xScaling,-399.025 * _yScaling,208.262 * _xScaling,-396.25 * _yScaling,);
    path.cubicTo(208.262 * _xScaling,-396.25 * _yScaling,208.262 * _xScaling,-396.25 * _yScaling,208.262 * _xScaling,-396.25 * _yScaling,);
    return path;
  }
  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => true;

}


class BottomClipArt extends CustomClipper<Path>{
  @override
  Path getClip(Size size) {
    Path path = Path();
    final double _xScaling = size.width / 414;
    final double _yScaling = size.height / 896;
    path.lineTo(-284.03 * _xScaling,452.676 * _yScaling);
    path.cubicTo(-308.175 * _xScaling,383.435 * _yScaling,-230.511 * _xScaling,319.971 * _yScaling,-185.714 * _xScaling,261.914 * _yScaling,);
    path.cubicTo(-152.421 * _xScaling,218.766 * _yScaling,-99.9443 * _xScaling,200.712 * _yScaling,-60.5541 * _xScaling,163.047 * _yScaling,);
    path.cubicTo(-7.07574 * _xScaling,111.911 * _yScaling,12.8058 * _xScaling,18.2642 * _yScaling,85.1817 * _xScaling,2.88348 * _yScaling,);
    path.cubicTo(157.808 * _xScaling,-12.5505 * _yScaling,227.759 * _xScaling,41.6941 * _yScaling,284.358 * _xScaling,89.7497 * _yScaling,);
    path.cubicTo(339.949 * _xScaling,136.949 * _yScaling,384.213 * _xScaling,198.23 * _yScaling,399.295 * _xScaling,269.579 * _yScaling,);
    path.cubicTo(413.901 * _xScaling,338.681 * _yScaling,404.972 * _xScaling,414.944 * _yScaling,365.473 * _xScaling,473.495 * _yScaling,);
    path.cubicTo(329.413 * _xScaling,526.948 * _yScaling,257.958 * _xScaling,535.891 * _yScaling,200.244 * _xScaling,564.642 * _yScaling,);
    path.cubicTo(150.853 * _xScaling,589.247 * _yScaling,107.424 * _xScaling,632.816 * _yScaling,52.3428 * _xScaling,629.488 * _yScaling,);
    path.cubicTo(-2.58967 * _xScaling,626.168 * _yScaling,-37.4736 * _xScaling,572.94 * _yScaling,-86.1865 * _xScaling,547.334 * _yScaling,);
    path.cubicTo(-152.522 * _xScaling,512.465 * _yScaling,-259.355 * _xScaling,523.438 * _yScaling,-284.03 * _xScaling,452.676 * _yScaling,);
    path.cubicTo(-284.03 * _xScaling,452.676 * _yScaling,-284.03 * _xScaling,452.676 * _yScaling,-284.03 * _xScaling,452.676 * _yScaling,);
    return path;
  }
  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => true;

}