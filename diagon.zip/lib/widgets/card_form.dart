import 'package:flutter/material.dart';
import 'package:diagon/utility/basket.dart';
class FormCard extends StatelessWidget {
  final double height;
  final double width;
  final double? padding;
  final Widget child;

  const FormCard({Key? key , required this.height, required this.width, required this.child, this.padding}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      height: height,
      width: width,
      padding:  EdgeInsets.all(padding ?? 20),
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
        color: basket['WhiteColor'],
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(color: Colors.black26,blurRadius: 2.0)]
      ),
      child: child,
    );
  }
}
