import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:diagon/utility/basket.dart';
import 'package:diagon/utility/globals.dart';
import 'package:diagon/widgets/card_form.dart';
import 'package:diagon/widgets/custom_button.dart';


class VerifyCode extends StatelessWidget {
  const VerifyCode({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const VerifyForm()
    );
  }
}


class VerifyForm extends StatefulWidget {
  const VerifyForm({Key? key}) : super(key: key);

  @override
  _VerifyFormState createState() => _VerifyFormState();
}

class _VerifyFormState extends State<VerifyForm> {
  late FocusNode _oneFocusNode;
  late FocusNode _twoFocusNode;
  late FocusNode _threeFocusNode;
  late FocusNode _fourFocusNode;
  late FocusNode _fiveFocusNode;
  late FocusNode _sixFocusNode;
  final TextEditingController _one =  TextEditingController();
  final TextEditingController _two =  TextEditingController();
  final TextEditingController _three =  TextEditingController();
  final TextEditingController _four =  TextEditingController();
  final TextEditingController _five =  TextEditingController();
  final TextEditingController _six =  TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();

    _oneFocusNode = FocusNode();
    _twoFocusNode = FocusNode();
    _threeFocusNode = FocusNode();
    _fourFocusNode = FocusNode();
    _fiveFocusNode = FocusNode();
    _sixFocusNode = FocusNode();
  }

  @override
  void dispose() {
    // Clean up the focus node when the Form is disposed.
    _oneFocusNode.dispose();
    _twoFocusNode.dispose();
    _threeFocusNode.dispose();
    _fourFocusNode.dispose();
    _fiveFocusNode.dispose();
    _sixFocusNode.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
       Form(
           key: _formKey,
           child:  Row(
         mainAxisAlignment: MainAxisAlignment.spaceBetween,
         children: [
           FormCard(
             padding: 10,
               height: 50, width: 50,
               child: TextFormField(

                 // maxLengthEnforcement: MaxLengthEnforcement.enforced,
                 focusNode: _oneFocusNode,
             keyboardType: TextInputType.number,
             controller: _one,
             onChanged: (val){
                   if(val != "" || val.isNotEmpty){
                     _one.text = val[0];
                    _twoFocusNode.requestFocus();}
                   else{
                     _oneFocusNode.requestFocus();
                   }
             },
                 validator: (input){
                   if(input != null && input.isNotEmpty){
                     if(input == GlobalVars.vCode.toString()[0]){
                     return null;
                     }
                     return "X";
                   }
                   return "Empty";
                 },
             style: const TextStyle(fontSize: 30),
             decoration: const InputDecoration(
               contentPadding: EdgeInsets.only(bottom: 10),

             ),


           )),
           FormCard(
             padding: 10,
               height: 50, width: 50, child: TextFormField(

             focusNode: _twoFocusNode,
             keyboardType: TextInputType.number,
             controller: _two,
             validator: (input){
               if(input != null && input.isNotEmpty){
                 if(input == GlobalVars.vCode.toString()[1]){
                   return null;
                 }
                 return "X";
               }
               return "Empty";
             },
             onChanged: (val){
            if(val != "" || val.isNotEmpty) {
              _two.text = val[0];
              _threeFocusNode.requestFocus();
            }else{
              _oneFocusNode.requestFocus();
            }
             },
             style: const TextStyle(fontSize: 30),
             decoration: const InputDecoration(
               contentPadding: EdgeInsets.only(bottom: 10),


             ),
           )),
           FormCard(height: 50, width: 50, child: TextFormField(

             focusNode: _threeFocusNode,
             keyboardType: TextInputType.number,
             controller: _three,
             validator: (input){
               if(input != null && input.isNotEmpty){
                 if(input == GlobalVars.vCode.toString()[2]){
                   return null;
                 }
                 return "X";
               }
               return "Empty";
             },
             onChanged: (val){
            if(val != "" || val.isNotEmpty) {
              _three.text = val[0];
               _fourFocusNode.requestFocus();
            }else{
              _twoFocusNode.requestFocus();
            }
             },
             style: const TextStyle(fontSize: 30),
             decoration: const InputDecoration(
               contentPadding: EdgeInsets.only(bottom: 10),
             ),),
             padding: 10,
           ),
           FormCard(height: 50, width: 50, child: TextFormField(

             focusNode: _fourFocusNode,
             keyboardType: TextInputType.number,
             controller: _four,
             validator: (input){
               if(input != null && input.isNotEmpty){
                 if(input == GlobalVars.vCode.toString()[3]){
                   return null;
                 }
                 return "X";
               }
               return "Empty";
             },
             onChanged: (val){
              if(val != "" || val.isNotEmpty) {
                _four.text = val[0];
                _fiveFocusNode.requestFocus();
              }else{
                _threeFocusNode.requestFocus();
              }
             },
             style: const TextStyle(fontSize: 30),
             decoration: const InputDecoration(
               contentPadding: EdgeInsets.only(bottom: 10),
             ),),
               padding: 10
           ), FormCard(height: 50, width: 50, child: TextFormField(
             focusNode: _fiveFocusNode,
             keyboardType: TextInputType.number,
             controller: _five,
             validator: (input){

               if(input != null && input.isNotEmpty){
                 if(input == GlobalVars.vCode.toString()[4]){
                   return null;
                 }
                 return "X";
               }
               return "Empty";
             },
             onChanged: (val){
              if(val != "" || val.isNotEmpty) {
                _five.text = val[0];
                _sixFocusNode.requestFocus();
              }else{
                _fourFocusNode.requestFocus();
              }
             },
             style: const TextStyle(fontSize: 30),
             decoration: const InputDecoration(
               contentPadding: EdgeInsets.only(bottom: 10),
             ),),
               padding: 10
           ),
           FormCard(height: 50, width: 50, child: TextFormField(

             maxLengthEnforcement: MaxLengthEnforcement.enforced,
             focusNode: _sixFocusNode,
             keyboardType: TextInputType.number,
             controller: _six,
             validator: (input){
               if(input != null && input.isNotEmpty){
                 if(input == GlobalVars.vCode.toString()[5]){
                   return null;
                 }
                 return "Invalid";
               }
               return "Empty";
             },
             onChanged: (val){
               if(val == "" || val.isEmpty) {
                 _fiveFocusNode.requestFocus();
               }else{
               _six.text = val[0];
               }
             },
             style: const TextStyle(fontSize: 30),
             decoration: const InputDecoration(
               contentPadding: EdgeInsets.only(bottom: 10),
             ),),
               padding: 10
           ),


         ],
       )),
        Container(
            margin: const EdgeInsets.only(top:50),
            child:
            TcRecButton(action: (){
              if(_formKey.currentState!.validate()){
                    // goTo(context, const SuccessPage());
              }
            },

              child:
              const Text("Verify", style: TextStyle(color: Colors.white,),
              ),
            )),
      ],
    );
  }
}
