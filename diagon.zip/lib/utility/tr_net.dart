import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'custom_exception.dart';

class Tr_Net {
  final appId = "com.example.diagon";
  static const _apiKey = "AIzaSyBgWb0fb3Skfz8RXfpNvzF2kDjeWNRQ5T8";
  String get apiKey => _apiKey;
  String? queryLink;
  final http.Client? trClient;
  // static final baseUrl = "https://lonux.com.ng/api/v1/";
  static const baseUrl = "https://dev.lonux.com.ng/api/v1/";
  static const localUrl = "http://172.20.10.5/";

  Tr_Net({this.trClient}) : assert(trClient != null);

// query api url with your http client for data using custom link as an argument
//using get method on api
  Future<dynamic> TrGoogleServiceGetRoute(l1, l2) async {
    String url = "https://maps.googleapis.com/maps/api/directions/json?origin=${l1.latitude},${l1.longitude}&destination=${l2.latitude},${l2.longitude}&key=$_apiKey";
    http.Response response = await http.get(Uri.parse(url));
    Map values = jsonDecode(response.body);
    return values["routes"][0]["overview_polyline"]["points"];
  }

  Future<dynamic> TrCustomGoogleServiceGetRoute(params, origin, dest) async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${dest.latitude},${dest.longitude}" +
            params +
            "&key=$_apiKey";
    http.Response response = await http.get(Uri.parse(url));
    Map values = jsonDecode(response.body);
    return values;
  }

  Future<dynamic> get(String url, {body, token, encoding}) async {
    var responseJson;
//    var scheme =
//      {
//        'app_id': appId,
//        'app_code':_apiKey,
//      };
//    var uri = new Uri.https(baseUrl, url,scheme);
//
    try {
      final response = await trClient!.get(Uri.parse(baseUrl + url),headers:
      {HttpHeaders.authorizationHeader: "Bearer $token","accept":"application/json"});

      if (response.statusCode == 200 || response.statusCode == 401) {
        responseJson = _response(response);
      }

      else {
        throw Exception('Request Error: ${response.statusCode}');
      }
    } on SocketException {
      print("caught error ");
    }

    return responseJson;
  }
//using post method on api

  Future<dynamic> post(String url,
      {body, headers , encoding}) async {
    var responseJson;
    headers??= {"accept":"application/json"};
    try {
      final result = await http
          .post(Uri.parse(baseUrl + url), body: body, headers: headers, encoding: encoding)
          .then((http.Response response) {
        final String res = response.body;
        print(res);
        final int statusCode = response.statusCode;
        if (statusCode < 200 || json == null) {
          throw Exception(
              "Error while fetching data, Error: ${response.statusCode}");
        }
//        if (statusCode >= 500) {
//          throw new Exception("Oops!!! Internal server error"+ statusCode.toString());
//
//        }
//        if (statusCode >= 400 && statusCode < 500) {
//          throw new Exception("Could not match your details - please try again with correct input");
//
//        }
        responseJson = _response(response);
      });
    } on SocketException {
      throw FetchDataException('No Internet connection');
    }
    return responseJson;
  }

  //handles the response from api
  dynamic _response(http.Response response) {
    switch (response.statusCode) {
      case 200:
        var responseJson;
        if (response.body.isNotEmpty) {
          print(response.body);
          responseJson = json.decode(response.body);
        } else {
          var result = {};
          responseJson = result;
        }
        return responseJson;
      case 400:
        throw BadRequestException(response.body.toString());
      case 401:
        return json.decode(response.body);
      case 403:
        throw UnauthorisedException(response.body.toString());
      case 422:
        var responseJson = json.decode(response.body);
        return responseJson;
      case 500:
        throw InternalServerError(response.body.toString());
      default:
        throw FetchDataException(
            'Error occured while Communicating with Server with StatusCode : ${response.statusCode}');
    }
  }
}
