

class GlobalVars {


  static int? vCode;


}